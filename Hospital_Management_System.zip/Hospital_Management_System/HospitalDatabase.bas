Attribute VB_Name = "HospitalDatabase"
Option Explicit

' Update this path after creating Hospital_Backend.accdb in Microsoft Access.
Public Const DB_PATH As String = "C:\HospitalSystem\Hospital_Backend.accdb"

Public Function GetConnection() As Object
    Dim cn As Object
    Set cn = CreateObject("ADODB.Connection")
    cn.Open "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & DB_PATH & ";Persist Security Info=False;"
    Set GetConnection = cn
End Function

' Example: save a patient from Excel to Access.
' Adjust the worksheet/cell references to match your form.
Public Sub SavePatientExample()
    Dim cn As Object, cmd As Object
    Set cn = GetConnection()
    Set cmd = CreateObject("ADODB.Command")
    Set cmd.ActiveConnection = cn
    cmd.CommandText = "INSERT INTO Patients (PatientID, FirstName, LastName, Gender, Phone) VALUES (?, ?, ?, ?, ?)"
    cmd.Parameters.Append cmd.CreateParameter(, 200, 1, 20, Sheets("Patients").Range("A2").Value)
    cmd.Parameters.Append cmd.CreateParameter(, 200, 1, 50, Sheets("Patients").Range("B2").Value)
    cmd.Parameters.Append cmd.CreateParameter(, 200, 1, 50, Sheets("Patients").Range("C2").Value)
    cmd.Parameters.Append cmd.CreateParameter(, 200, 1, 20, Sheets("Patients").Range("D2").Value)
    cmd.Parameters.Append cmd.CreateParameter(, 200, 1, 30, Sheets("Patients").Range("F2").Value)
    cmd.Execute
    cn.Close
    MsgBox "Patient saved successfully.", vbInformation
End Sub

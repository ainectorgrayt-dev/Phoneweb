HOSPITAL MANAGEMENT SYSTEM – PROJECT PACKAGE

FILES
1. Hospital_Front_End.xlsx
   Excel front-end workbook with dashboard, data sheets and validation.

2. Access_Database_Schema.sql
   SQL schema for creating the Microsoft Access back-end tables.

3. HospitalDatabase.bas
   VBA/ADODB starter module for connecting Excel to Access.

4. Project_Documentation.docx
   Academic project documentation.

5. Hospital_System_Presentation.pptx
   PowerPoint presentation outline.

HOW TO COMPLETE THE ACCESS BACK END
1. On a Windows computer with Microsoft Access, create a blank database named Hospital_Backend.accdb.
2. Open the supplied Access_Database_Schema.sql and execute/create the tables in Access. If your Access version does not execute the whole script at once, create the tables manually using the same fields.
3. Create the relationships listed at the bottom of the SQL file.
4. Save the database as Hospital_Backend.accdb.
5. Open the Excel workbook and save it as Hospital_Front_End.xlsm.
6. Press Alt+F11 → File → Import File → select HospitalDatabase.bas.
7. Edit DB_PATH in the VBA module to point to your .accdb file.
8. Add buttons/forms as required and connect them to the VBA procedures.
9. Test with sample/fake hospital data before demonstration.

IMPORTANT
This is an academic starter package, not a production hospital system. Do not store real patient information in the sample files.

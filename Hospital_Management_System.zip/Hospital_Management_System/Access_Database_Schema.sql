CREATE TABLE Patients (
 PatientID TEXT(20) PRIMARY KEY,
 FirstName TEXT(50),
 LastName TEXT(50),
 Gender TEXT(20),
 DateOfBirth DATETIME,
 Phone TEXT(30),
 Address TEXT(150),
 BloodGroup TEXT(10),
 EmergencyContact TEXT(100)
);

CREATE TABLE Doctors (
 DoctorID TEXT(20) PRIMARY KEY,
 FirstName TEXT(50),
 LastName TEXT(50),
 Specialization TEXT(80),
 Phone TEXT(30),
 Email TEXT(100)
);

CREATE TABLE Appointments (
 AppointmentID TEXT(20) PRIMARY KEY,
 PatientID TEXT(20),
 DoctorID TEXT(20),
 AppointmentDate DATETIME,
 AppointmentTime TEXT(20),
 Reason TEXT(150),
 Status TEXT(30)
);

CREATE TABLE MedicalRecords (
 RecordID TEXT(20) PRIMARY KEY,
 PatientID TEXT(20),
 DoctorID TEXT(20),
 VisitDate DATETIME,
 Diagnosis TEXT(255),
 Treatment TEXT(255),
 Notes TEXT(255)
);

CREATE TABLE Admissions (
 AdmissionID TEXT(20) PRIMARY KEY,
 PatientID TEXT(20),
 Ward TEXT(80),
 BedNumber TEXT(20),
 AdmissionDate DATETIME,
 DischargeDate DATETIME,
 Status TEXT(30)
);

CREATE TABLE Medications (
 MedicineID TEXT(20) PRIMARY KEY,
 MedicineName TEXT(100),
 Category TEXT(80),
 Quantity INTEGER,
 UnitPrice CURRENCY,
 ExpiryDate DATETIME
);

CREATE TABLE Prescriptions (
 PrescriptionID TEXT(20) PRIMARY KEY,
 PatientID TEXT(20),
 DoctorID TEXT(20),
 MedicineID TEXT(20),
 Dosage TEXT(80),
 Frequency TEXT(80),
 Duration TEXT(80),
 PrescriptionDate DATETIME
);

CREATE TABLE Bills (
 BillID TEXT(20) PRIMARY KEY,
 PatientID TEXT(20),
 Service TEXT(100),
 Description TEXT(255),
 Amount CURRENCY,
 BillDate DATETIME,
 PaymentStatus TEXT(30)
);

-- Recommended relationships:
-- Patients.PatientID -> Appointments.PatientID
-- Doctors.DoctorID -> Appointments.DoctorID
-- Patients.PatientID -> MedicalRecords.PatientID
-- Doctors.DoctorID -> MedicalRecords.DoctorID
-- Patients.PatientID -> Admissions.PatientID
-- Patients.PatientID -> Prescriptions.PatientID
-- Doctors.DoctorID -> Prescriptions.DoctorID
-- Medications.MedicineID -> Prescriptions.MedicineID
-- Patients.PatientID -> Bills.PatientID